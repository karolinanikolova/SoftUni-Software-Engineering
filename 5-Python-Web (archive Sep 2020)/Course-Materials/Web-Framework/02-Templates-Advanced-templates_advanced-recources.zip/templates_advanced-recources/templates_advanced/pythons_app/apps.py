from django.apps import AppConfig


class PythonsAppConfig(AppConfig):
    name = 'pythons_app'
